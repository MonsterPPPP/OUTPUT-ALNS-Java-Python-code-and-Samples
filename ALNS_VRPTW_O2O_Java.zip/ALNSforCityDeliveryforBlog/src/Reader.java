import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Reader {
	public String path;
	public Reader(String x) {
		this.path=x;
	}
	//��ȡcsv�ļ������ҽ���Ӧ��ֵд�뵽Helper�еı�������
	public void readCsv(){
		String[] str= {"pick_lng","pick_lat","deliver_lng",//����д�ϱ�����
				"deliver_lat","assigned_time","estimate_pick_time",
				"promise_deliver_time","area1","area2"};
		File inFile=new File(path);
		String inString="";
		try {
			BufferedReader reader =new BufferedReader(new FileReader(inFile));
			int countNumber=-1;//��һ�в��㣬���ڼ�¼�ܵ���
			while((inString=reader.readLine())!=null) {
				countNumber++;
			}
			reader =new BufferedReader(new FileReader(inFile));
			
			String[][] content=new String[countNumber][str.length];//���ڼ�¼������Ϣ
			
			
			Helper.orderNumber=countNumber;//��orderNumber����ֵ
			Helper.pointNumber=2*Helper.orderNumber;
			Helper.courierNumber=Helper.orderNumber/2;
			
			System.out.println("�ܵ�����"+countNumber);
			countNumber=-2;
			while((inString=reader.readLine())!=null) {//��ȡcsv�ļ���������ݲ�����content��
				if(countNumber==-2) {
					countNumber++;
					continue;//������һ��
				}else countNumber++;
				//System.out.println(countNumber);
				String[] strr=inString.split(",");
				content[countNumber]=strr;
			}

			//����������
			double[][] disM=new double[Helper.orderNumber*2][Helper.orderNumber*2];
			for(int i=0;i<Helper.orderNumber*2;i++) {
				for(int j=0;j<Helper.orderNumber*2;j++) {
					if(i==j) {
						disM[i][j]=0;
					}
					if(i%2==0&&j%2==0) {//�����ż��
						disM[i][j]=lineDistance(content[i/2][0],content[i/2][1],content[j/2][0],content[j/2][1]);
					}
					if(i%2==0&&j%2!=0) {
						disM[i][j]=lineDistance(content[i/2][0],content[i/2][1],content[j/2][2],content[j/2][3]);
					}
					if(i%2!=0&&j%2==0) {
						disM[i][j]=lineDistance(content[i/2][2],content[i/2][3],content[j/2][0],content[j/2][1]);
					}
					if(i%2!=0&&j%2!=0) {
						disM[i][j]=lineDistance(content[i/2][2],content[i/2][3],content[j/2][2],content[j/2][3]);
					}
				}
			}
			Helper.distanceMartix=disM;//�������ֵ���
			
			//��������ʱ�������Helper��
			int[][] timeT=new int[Helper.orderNumber][3];
			for(int i=0;i<Helper.orderNumber;i++) {
				timeT[i][0]=Integer.parseInt(content[i][4]);
				timeT[i][1]=Integer.parseInt(content[i][5]);
				timeT[i][2]=Integer.parseInt(content[i][6]);
			}
			Helper.timeTable=timeT;
			
			//�����������򻮷������Helper��
			int[][] pointA=new int[Helper.pointNumber][1];
			for(int i=0;i<Helper.orderNumber;i++) {
					pointA[i][0]=Integer.parseInt(content[i/2][7]);
			}
			Helper.pointArea=pointA;
		}
		catch(FileNotFoundException ex) {
			System.out.println("�ļ�û�ҵ���");
		}
		catch(IOException ex) {
			System.out.println("��д�ļ�������");
		}
	}
	//���ڼ���ֱ�߾��룬����m
	public double lineDistance(String lng1Str,String lat1Str,String lng2Str,String lat2Str) {
        Double lat1 = Double.parseDouble(lat1Str);
        Double lng1 = Double.parseDouble(lng1Str);
        Double lat2 = Double.parseDouble(lat2Str);
        Double lng2 = Double.parseDouble(lng2Str);
         
        double radLat1 = rad(lat1);
        double radLat2 = rad(lat2);
        double difference = radLat1 - radLat2;
        double mdifference = rad(lng1) - rad(lng2);
        double distance = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(difference / 2), 2)
                + Math.cos(radLat1) * Math.cos(radLat2)
                * Math.pow(Math.sin(mdifference / 2), 2)));
        distance = distance * EARTH_RADIUS;
        distance = Math.round(distance * 10000) / 10000;
        return distance;
	}
    private static double EARTH_RADIUS = 6378200; 
    
    private static double rad(double d) { 
        return d * Math.PI / 180.0; 
    }
}










