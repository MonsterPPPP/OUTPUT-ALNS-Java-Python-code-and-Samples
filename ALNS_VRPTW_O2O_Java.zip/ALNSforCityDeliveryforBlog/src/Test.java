import java.util.Iterator;

public class Test {
	public static void main(String[] args) {
		Courier t1=new Courier(0);
		t1.deliverOrder.add(0);
		t1.deliverOrder.add(1);
		Iterator<Integer> i1=t1.deliverOrder.iterator();
		while(i1.hasNext()) {
			System.out.println(i1.next());
		}
		t1.lossCalc() ;
		System.out.println(t1.distanceLoss);
		System.out.println(t1.overTimeLoss);
		System.out.println(t1.timeLoss);
		
	}
}
